﻿using BloodBankMangementSystem.Entity;
using BloodBankMangementSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankMangementSystem.DAL
{
    public class BloodBankDL
    {
        //string conStr = @"data source=(LocalDB)\SoumickLocalDB;initial catalog=CapgeminiPractice";
        string conStr = @"data source=ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog=Training_19Sep18_Pune";
        SqlConnection con;
        SqlCommand com;

        public bool AddBloodBankDetailsDL(BloodBankDetails bbDetails)
        {
            bool DetailsAdded = false;
            try
            {
                con = new SqlConnection(conStr);

                com = new SqlCommand("BBMS.uspAddBloodBankDetails2", con);

                com.CommandType = CommandType.StoredProcedure;

                com.Parameters.AddWithValue("@bbID", bbDetails.BloodBankID);

                com.Parameters.AddWithValue("@bbName", bbDetails.BloodBankName);

                com.Parameters.AddWithValue("@bbAddress", bbDetails.Address);

                com.Parameters.AddWithValue("@bbCity", bbDetails.City);

                com.Parameters.AddWithValue("@bbContactNo", bbDetails.ContactNumber);

                //com.Parameters.AddWithValue("@bbUserID", bbDetails.UserID);

                //com.Parameters.AddWithValue("@bbPassword", bbDetails.Password);

                con.Open();

                com.ExecuteNonQuery();
                DetailsAdded = true;
            }
            catch (BloodBankExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return DetailsAdded;
        }

        public int VerifyBloodBankIDDL(string bloodBankID)
        {
            int idFound = 0;

            try
            {
                con = new SqlConnection(conStr);

                com = new SqlCommand("BBMS.uspVerifyBloodBankID", con);

                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@bbID", bloodBankID);

                con.Open();
                idFound = int.Parse(com.ExecuteScalar().ToString());
            }
            catch (BloodBankExceptions) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return idFound;
        }
    }
}
