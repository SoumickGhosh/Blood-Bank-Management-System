﻿using BloodBankMangementSystem.DAL;
using BloodBankMangementSystem.Entity;
using BloodBankMangementSystem.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BloodBankMangementSystem.BLL
{
    public class BloodBankBL
    {

        public bool AddBloodBankDetailsBL(BloodBankDetails bloodBankDetails)
        {
            
            try
            {
                 BloodBankDL bbDAL = new BloodBankDL();
                 return bbDAL.AddBloodBankDetailsDL(bloodBankDetails);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
            
        }

        public bool ValidateData(string bbID,string bbName,string bbAddress,string bbCity,string bbContact)
        {
            Regex r = new Regex("[7-9]{1}[0-9]{9}");
            bool Contact = r.IsMatch(bbContact);
            Regex r2 = new Regex("[B]{1}[B]{1}[0-9]{5}");

            StringBuilder sb = new StringBuilder();
            bool valid = true;
            if (bbID == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Bank ID cannot be empty");
            }
            else if (!r2.IsMatch(bbID))
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Bank ID is not in proper format");
            }
            
            if (bbName == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nBlood Bank Name cannot be empty");
            }
            if (bbAddress == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nAddress cannot be empty");
            }
            if (bbCity == "")
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nCity cannot be empty");
            }
            if(!Contact)
            {
                valid = false;
                sb.Append(Environment.NewLine + "\nPhone number is not proper");
            }
            if (valid == false)
                throw new BloodBankExceptions(sb.ToString());
            return valid;
        }

        public int VerifyBloodBankIDBL(string bloodbankID)
        {
            try
            {
                BloodBankDL bbDAL = new BloodBankDL();
                return bbDAL.VerifyBloodBankIDDL(bloodbankID);
            }
            catch (BloodBankExceptions)
            {
                throw;
            }
        }
            
    }
}
