﻿using System;

namespace BloodBankMangementSystem.Entities
{
    public class Class1
    {
    }
}
