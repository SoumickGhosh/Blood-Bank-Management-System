use BloodBankDB

use Training_19Sep18_Pune

create schema BBMS

create table BBMS.BloodBank
(
BloodBankID varchar(50) primary key,
BloodBankName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
ContactNumber bigint not null,
UserID varchar(50),
Password varchar(50) 
)

create table BBMS.BloodDonationCamp
(
BloodDonationCampID varchar(50) primary key,
CampName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
BloodBank varchar(50) not null,
CampStartDate date not null,
CampEndDate date not null
)

create table BBMS.BloodDonor
(
BloodDonorID varchar(50) primary key,
FirstName varchar(50) not null,
LastName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
MobileNo bigint not null,
BloodGroup varchar(50) not null
)

create table BBMS.BloodDonorDonation
(
BloodDonationID varchar(50) primary key,
BloodDonorID varchar(50) not null,
BloodDonationDate date not null,
NumberOfBottles int not null,
Weight float not null,
HBCount float not null
)

create table BBMS.BloodInventory
(
BloodInvenoryID varchar(50) primary key,
BloodGroup varchar(50) not null,
NumberOfBottles int not null,
BloodBankID varchar(50) not null,
ExpiryDate date not null
)

create table BBMS.Hospital
(
HospitalID varchar(50) primary key,
HospitalName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
ContactNo bigint not null
)

create proc BBMS.uspVerifyBloodBankID
(
@bbID varchar(50)
)
as 
begin 
	select count(*) from BBMS.BloodBank where BloodBankID=@bbID
end 



create proc BBMS.uspAddBloodBankDetails
(
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint,
@bbUserID varchar(50),
@bbPassword varchar(50)
)
as
begin
	insert into BBMS.BloodBank values
(@bbID,
@bbName,
@bbAddress,
@bbCity,
@bbContactNo,
@bbUserID,
@bbPassword) 
end

create proc BBMS.uspAddBloodBankDetails2
(
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint
)
as
begin
	insert into BBMS.BloodBank
(BloodBankID,
BloodBankName,
Address,
City,
ContactNumber) values
(@bbID,
@bbName,
@bbAddress,
@bbCity,
@bbContactNo
) 
end

create proc BBMS.uspDisplayAllBloodBankDetails
as
begin
select BloodBankID,BloodBankName,Address,City,ContactNumber from BBMS.BloodBank
end

create proc BBMS.uspUserLogin
(
@bbUserID varchar(50)
)
as
begin
	select Password from BBMS.BloodBank
	where UserID=@bbUserID
end

create proc BBMS.uspSearchForDuplicateUser
(
@bbUserID varchar(50)
)
as 
begin
	select count(*) from BBMS.BloodBank where UserID=@bbUserID
end

create proc BBMS.uspUpdateBloodBankDetails
(
@bbID varchar(50),
@bbName varchar(50),
@bbAddress varchar(50),
@bbCity varchar(50),
@bbContactNo bigint
)
as
begin
	update BBMS.BloodBank set BloodBankName=@bbName,
	Address=@bbAddress,
	City=@bbCity,
	ContactNumber=@bbContactNo
	where
	BloodBankID=@bbID
end

create proc BBMS.uspBloodBankID
as
begin
	select BloodBankID from BBMS.BloodBank
end


create proc BBMS.uspSearchBloodBankDetails
(
@bbID varchar(50)
)
as
begin
	select BloodBankName,
	Address,
	City,
	ContactNumber from BBMS.BloodBank where BloodBankID=@bbID
end

create proc BBMS.uspDeleteBloodBankDetails
(
@bbID varchar(50)
)
as 
begin
	delete from BBMS.BloodBank where BloodBankID=@bbID
end

