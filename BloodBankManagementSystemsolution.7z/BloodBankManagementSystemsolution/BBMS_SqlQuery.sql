use CapgeminiPractice

create schema BBMS

create table BBMS.BloodBank
(
BloodBankID varchar(50) primary key,
BloodBankName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
ContactNumber bigint not null,
UserID varchar(50) not null,
Password varchar(50) not null
)

create table BBMS.BloodDonationCamp
(
BloodDonationCampID varchar(50) primary key,
CampName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
BloodBank varchar(50) not null,
CampStartDate date not null,
CampEndDate date not null
)

create table BBMS.BloodDonor
(
BloodDonorID varchar(50) primary key,
FirstName varchar(50) not null,
LastName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
MobileNo bigint not null,
BloodGroup varchar(50) not null
)

create table BBMS.BloodDonorDonation
(
BloodDonationID varchar(50) primary key,
BloodDonorID varchar(50) not null,
BloodDonationDate date not null,
NumberOfBottles int not null,
Weight float not null,
HBCount float not null
)

create table BBMS.BloodInventory
(
BloodInvenoryID varchar(50) primary key,
BloodGroup varchar(50) not null,
NumberOfBottles int not null,
BloodBankID varchar(50) not null,
ExpiryDate date not null
)

create table BBMS.Hospital
(
HospitalID varchar(50) primary key,
HospitalName varchar(50) not null,
Address varchar(50) not null,
City varchar(50) not null,
ContactNo bigint not null
)